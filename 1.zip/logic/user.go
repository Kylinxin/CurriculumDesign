package logic

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strings"
	"sync/atomic"
	"time"

	"github.com/spf13/cast"
	"github.com/spf13/viper"
	"nhooyr.io/websocket"
	"nhooyr.io/websocket/wsjson"
)

var gobalUid uint32 = 0

type user struct {
	Uid        int `json:uid`
	Nickname   string
	EnterAt    time.Time
	Addr       string
	Msgchannel chan *Message
	conn       *websocket.Conn
	Token      string
	isnew      bool
}

var System = &user{}

func genToken(uid int, nickname string) string {
	secret := viper.GetString("secret-key")
	message := fmt.Sprintf("%s%s%d", nickname, secret, uid)
	messageMac := macSha256([]byte(message), []byte(secret))
	return fmt.Sprintf("%suid%d", base64.StdEncoding.EncodeToString(messageMac), uid)
}

func parseandvalidatetoke(token, nickname string) (int, error) {
	loc := strings.LastIndex(token, "uid")
	messageMac, err := base64.StdEncoding.DecodeString(token[:loc])
	if err != nil {
		return 0, err
	}
	uid := cast.ToInt(token[loc+3:])
	secret := viper.GetString("secret-key")
	message := fmt.Sprintf("%s%s%d", nickname, secret, uid)
	ok := validateSha256([]byte(message), []byte(messageMac), []byte(secret))
	if ok {
		return uid, nil
	}
	return 0, errors.New("The token is illegal")
}

func macSha256(message, secret []byte) []byte {
	mac := hmac.New(sha256.New, secret)
	mac.Write(message)
	return mac.Sum(nil)
}

func validateSha256(message, messageMac, secret []byte) bool {
	mac := hmac.New(sha256.New, secret)
	mac.Write(message)
	expectedMac := mac.Sum(nil)
	return hmac.Equal(messageMac, expectedMac)
}

func Newuser(conn *websocket.Conn, nickname, token, addr string) *user {
	user := &user{
		Nickname:   nickname,
		Addr:       addr,
		EnterAt:    time.Now(),
		Token:      token,
		conn:       conn,
		Msgchannel: make(chan *Message, 32),
	}
	if user.Token != "" {
		uid, err := parseandvalidatetoke(token, nickname)
		if err == nil {
			user.Uid = uid
		}
	}
	if user.Uid == 0 {
		user.Uid = int(atomic.AddUint32(&gobalUid, 1))
		user.Token = genToken(user.Uid, user.Nickname)
		user.isnew = true
	}
	return user
}

func (u *user) Sendmessage(ctx context.Context) {
	for msg := range u.Msgchannel {
		wsjson.Write(ctx, u.conn, msg)
	}
}

func (u *user) closemessage() {
	close(u.Msgchannel)
}

func (u *user) Receivemessage(ctx context.Context) error {
	var (
		ReceiveMsg map[string]string
		err        error
	)
	for {
		err = wsjson.Read(ctx, u.conn, &ReceiveMsg)
		if err != nil {
			var closeerr websocket.CloseError
			if errors.As(err, &closeerr) {
				return nil
			} else if errors.Is(err, io.EOF) {
				return nil
			}
			return err
		}
		sendMsg := Newmessage(u, ReceiveMsg["content"], ReceiveMsg["send_time"])
		//筛选敏感字符

		reg := regexp.MustCompile(`@[^\s@]{2,20}`)
		sendMsg.Ats = reg.FindAllString(sendMsg.Content, -1)
		Broadcaster.Broadcast(sendMsg)
	}
}
