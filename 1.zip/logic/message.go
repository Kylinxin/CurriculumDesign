package logic

import (
	"time"

	"github.com/spf13/cast"
)

const (
	Msgcommon = iota
	Msgwelcome
	Msgenter
	Msgexit
	Msgerror
)

type Message struct {
	Username    *user
	Type        int
	Content     string
	Ats         []string
	Msgtime     time.Time
	Client_time time.Time
}

func Newmessage(user *user, content, Client_time string) *Message {
	message := &Message{
		Username: user,
		Type:     Msgcommon,
		Content:  content,
		Msgtime:  time.Now(),
	}
	if Client_time != "" {
		message.Client_time = time.Unix(0, cast.ToInt64(Client_time))
	}
	return message
}

func Newmessagewelcome(user *user) *Message {
	return &Message{
		Username: user,
		Type:     Msgwelcome,
		Content:  user.Nickname + "欢迎来到聊天室！",
		Msgtime:  time.Now(),
	}
}

func Newmessageleave(user *user) *Message {
	return &Message{
		Username: user,
		Type:     Msgexit,
		Content:  user.Nickname + "离开了聊天室",
		Msgtime:  time.Now(),
	}
}

func Newmessageenter(user *user) *Message {
	return &Message{
		Username: user,
		Type:     Msgenter,
		Content:  user.Nickname + "进入了聊天室",
	}
}

func Newmessageerror(content string) *Message {
	return &Message{
		Username: System,
		Type:     Msgerror,
		Content:  content,
		Msgtime:  time.Now(),
	}
}
