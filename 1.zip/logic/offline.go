package logic

import (
	"container/ring"

	"github.com/spf13/viper"
)

var OfflineProcessor = newprocessor()

type offlineprocessor struct {
	n          int
	recentring *ring.Ring            //记录所有用户的离线数据
	userring   map[string]*ring.Ring //记录某个用户的离线数据
}

func newprocessor() *offlineprocessor {
	num := viper.GetInt("offline-num")
	return &offlineprocessor{
		n:          num,
		recentring: ring.New(num),
		userring:   make(map[string]*ring.Ring),
	}
}

// 采用表存储相关的数据
func (o *offlineprocessor) Save(msg *Message) {
	if msg.Type != Msgcommon {
		return
	}
	o.recentring.Value = msg
	o.recentring = o.recentring.Next()
	for _, nickname := range msg.Ats {
		nickname = nickname[1:]
		var (
			r  *ring.Ring
			ok bool
		)
		if r, ok = o.userring[nickname]; !ok {
			r = ring.New(o.n)
		}
		r.Value = msg
		o.userring[nickname] = r.Next()
	}
}

func (o *offlineprocessor) Send(user *user) {
	o.recentring.Do(func(value interface{}) {
		if value != nil {
			user.Msgchannel <- value.(*Message)
		}
	})
	if user.isnew {
		return
	}
	if r, ok := o.userring[user.Nickname]; ok {
		r.Do(func(value interface{}) {
			if value != nil {
				user.Msgchannel <- value.(*Message)
			}
		})
		delete(o.userring, user.Nickname)
	}
}
